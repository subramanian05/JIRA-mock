# JIRA Clone
This project is a simplified JIRA-like application with full CRUD operations.
